#include "rag_server_runtime.h"

#include "log.h"
#include "repo_scanner.h"

#include <algorithm>
#include <cctype>
#include <sstream>
#include <stdexcept>

namespace {

std::string trim_copy(std::string value) {
    auto not_space = [](unsigned char ch) { return !std::isspace(ch); };
    value.erase(value.begin(), std::find_if(value.begin(), value.end(), not_space));
    value.erase(std::find_if(value.rbegin(), value.rend(), not_space).base(), value.end());
    return value;
}

json parse_rag_metadata(const std::string & metadata) {
    json out = json::object();
    if (metadata.empty()) {
        return out;
    }

    std::stringstream stream(metadata);
    std::string part;
    while (std::getline(stream, part, ';')) {
        const size_t pos = part.find('=');
        if (pos == std::string::npos) {
            continue;
        }
        const std::string key = trim_copy(part.substr(0, pos));
        const std::string value = trim_copy(part.substr(pos + 1));
        if (!key.empty()) {
            out[key] = value;
        }
    }

    return out;
}

std::string sanitize_rag_preview(std::string text, size_t max_chars = 240) {
    text = trim_copy(text);
    for (char & ch : text) {
        if (ch == '\r' || ch == '\n' || ch == '\t') {
            ch = ' ';
        }
    }
    if (text.size() > max_chars) {
        text.resize(max_chars);
        text += "...";
    }
    return text;
}

std::string format_rag_source_label(const json & metadata) {
    const std::string path = metadata.value("path", "");
    const std::string lines_begin = metadata.value("start_line", "");
    const std::string lines_end = metadata.value("end_line", "");
    if (!path.empty() && !lines_begin.empty() && !lines_end.empty()) {
        return path + ":" + lines_begin + "-" + lines_end;
    }
    if (!path.empty()) {
        return path;
    }
    return "retrieved-context";
}

std::string extract_text_from_message_content(const json & content) {
    if (content.is_string()) {
        return content.get<std::string>();
    }
    if (!content.is_array()) {
        return "";
    }

    std::string text;
    for (const auto & item : content) {
        if (!item.is_object()) {
            continue;
        }
        if (item.value("type", "") == "text" && item.contains("text") && item["text"].is_string()) {
            if (!text.empty()) {
                text += '\n';
            }
            text += item["text"].get<std::string>();
        }
    }
    return text;
}

std::string build_rag_context_block(const std::vector<RagSearchResult> & results) {
    if (results.empty()) {
        return "";
    }

    std::string block = "Retrieved project context:\n";
    for (size_t i = 0; i < results.size(); ++i) {
        const json metadata = parse_rag_metadata(results[i].metadata);
        block += "\n[" + std::to_string(i + 1) + "] " + format_rag_source_label(metadata) + "\n";
        block += sanitize_rag_preview(results[i].chunk_text, 480) + "\n";
    }
    return block;
}

json build_source_info(const json & metadata) {
    return json{
        {"path", metadata.value("path", "")},
        {"language", metadata.value("language", "")},
        {"start_line", metadata.value("start_line", "")},
        {"end_line", metadata.value("end_line", "")},
    };
}

} // namespace

RagServerRuntime::RagServerRuntime() = default;

RagServerRuntime::~RagServerRuntime() {
    shutdown();
}

bool RagServerRuntime::init(common_params & params, llama_model * model, llama_context * ctx_main, const llama_vocab * vocab) {
    shutdown();

    params_base_ = params;
    model_ = model;
    vocab_ = vocab;

    if (!params_base_.rag_enable || model_ == nullptr || ctx_main == nullptr || vocab_ == nullptr) {
        return false;
    }

    ctx_embed_ = nullptr;

    if (!params_base_.model_embed_path.empty()) {
        auto embed_params = params_base_;
        embed_params.model.path = params_base_.model_embed_path;
        embed_params.n_gpu_layers = params_base_.n_gpu_layers_embed;
        embed_params.embedding = true;
        embed_params.pooling_type = LLAMA_POOLING_TYPE_MEAN;
        embed_params.attention_type = LLAMA_ATTENTION_TYPE_NON_CAUSAL;
        embed_params.n_parallel = 1;

        llama_init_embed_ = common_init_from_params(embed_params);
        if (llama_init_embed_ && llama_init_embed_->model() && llama_init_embed_->context()) {
            ctx_embed_ = llama_init_embed_->context();
            LOG_INF("%s: loaded dedicated embedding model '%s'\n", __func__, params_base_.model_embed_path.c_str());
        } else {
            LOG_WRN("%s: failed to load dedicated embedding model, falling back to the main model when possible\n", __func__);
        }
    }

    if (ctx_embed_ == nullptr) {
        if (llama_pooling_type(ctx_main) == LLAMA_POOLING_TYPE_NONE) {
            LOG_ERR("%s: RAG requested but the main model does not expose embeddings and no dedicated embedding model is configured\n", __func__);
            return false;
        }

        auto embed_params = params_base_;
        embed_params.embedding = true;
        embed_params.pooling_type = LLAMA_POOLING_TYPE_LAST;
        embed_params.n_parallel = 1;

        auto cparams_embed = common_context_params_to_llama(embed_params);
        ctx_embed_owned_.reset(llama_init_from_model(model_, cparams_embed));
        if (!ctx_embed_owned_) {
            LOG_ERR("%s: failed to create a dedicated embedding context from the main model\n", __func__);
            return false;
        }

        ctx_embed_ = ctx_embed_owned_.get();
        LOG_INF("%s: created a dedicated embedding context from the main model\n", __func__);
    }

    RagConfig rag_config;
    rag_config.index_path = params_base_.rag_index_path;
    rag_config.top_k = params_base_.rag_top_k;
    rag_config.chunk_size = params_base_.rag_chunk_size;
    rag_config.chunk_overlap = params_base_.rag_chunk_overlap;
    rag_config.use_hybrid = params_base_.rag_hybrid_search;

    rag_engine_ = std::make_unique<RagEngine>(rag_config);
    const llama_model * rag_model = llama_init_embed_ ? llama_init_embed_->model() : model_;
    if (!rag_engine_->init(ctx_embed_, rag_model, vocab_)) {
        LOG_ERR("%s: failed to initialize RAG engine\n", __func__);
        rag_engine_.reset();
        return false;
    }

    start_worker();
    params = params_base_;
    return true;
}

void RagServerRuntime::shutdown() {
    if (running_) {
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            running_ = false;
        }
        queue_cv_.notify_all();
        if (worker_.joinable()) {
            worker_.join();
        }
    }

    if (rag_engine_) {
        rag_engine_->save();
        rag_engine_.reset();
    }

    llama_init_embed_.reset();
    ctx_embed_owned_.reset();
    ctx_embed_ = nullptr;
    model_ = nullptr;
    vocab_ = nullptr;

    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        std::queue<ingest_job> empty;
        std::swap(pending_jobs_, empty);
    }

    pending_count_ = 0;
    job_active_ = false;
}

bool RagServerRuntime::enabled() const {
    return params_base_.rag_enable && rag_engine_ != nullptr;
}

bool RagServerRuntime::ready() const {
    return rag_engine_ && rag_engine_->is_ready();
}

void RagServerRuntime::start_worker() {
    running_ = true;
    worker_ = std::thread([this]() { worker_loop(); });
}

void RagServerRuntime::worker_loop() {
    while (true) {
        ingest_job job;
        {
            std::unique_lock<std::mutex> lock(queue_mutex_);
            queue_cv_.wait(lock, [this]() {
                return !pending_jobs_.empty() || !running_;
            });

            if (!running_ && pending_jobs_.empty()) {
                break;
            }

            job = std::move(pending_jobs_.front());
            pending_jobs_.pop();
        }

        pending_count_--;
        job_active_ = true;
        try {
            if (rag_engine_) {
                if (job.reset_before_add) {
                    rag_engine_->clear();
                }
                rag_engine_->add_documents(job.docs, job.metadata);
            }

            {
                std::lock_guard<std::mutex> lock(status_mutex_);
                last_error_.clear();
                last_job_kind_ = job.kind;
                last_reset_before_add_ = job.reset_before_add;
            }

            jobs_completed_++;
            docs_completed_ += (int) job.docs.size();
            metadata_completed_ += (int) job.metadata.size();
        } catch (const std::exception & e) {
            std::lock_guard<std::mutex> lock(status_mutex_);
            last_error_ = e.what();
            last_job_kind_ = job.kind;
            last_reset_before_add_ = job.reset_before_add;
        }
        job_active_ = false;
    }
}

bool RagServerRuntime::enqueue_documents(
    const std::vector<std::string> & docs,
    const std::vector<std::string> & metadata,
    bool reset_before_add,
    std::string * error_message) {
    if (!enabled()) {
        if (error_message) {
            *error_message = "RAG is not enabled";
        }
        return false;
    }

    ingest_job job;
    job.docs = docs;
    job.metadata = metadata;
    job.reset_before_add = reset_before_add;
    job.kind = "documents";

    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        pending_jobs_.push(std::move(job));
        pending_count_++;
    }
    queue_cv_.notify_one();
    return true;
}

bool RagServerRuntime::enqueue_repo_index(
    const std::string & repo_path,
    bool reset_before_add,
    std::string * error_message) {
    if (!enabled()) {
        if (error_message) {
            *error_message = "RAG is not enabled";
        }
        return false;
    }

    try {
        RepoScannerResult scan = RepoScanner::scan(repo_path);
        std::vector<std::string> docs;
        std::vector<std::string> metadata;
        docs.reserve(scan.chunks.size());
        metadata.reserve(scan.chunks.size());
        for (const auto & chunk : scan.chunks) {
            docs.push_back(chunk.text);
            metadata.push_back(chunk.metadata);
        }
        return enqueue_documents(docs, metadata, reset_before_add, error_message);
    } catch (const std::exception & e) {
        if (error_message) {
            *error_message = e.what();
        }
        return false;
    }
}

std::vector<RagSearchResult> RagServerRuntime::search_with_metadata(const std::string & query, int top_k, int timeout_ms) const {
    if (!enabled() || query.empty()) {
        return {};
    }
    return rag_engine_->search_with_metadata(query, top_k, timeout_ms);
}

json RagServerRuntime::build_search_payload(const std::string & query, int top_k, int timeout_ms) const {
    const auto results = search_with_metadata(query, top_k, timeout_ms);
    json items = json::array();

    for (size_t i = 0; i < results.size(); ++i) {
        const json metadata = parse_rag_metadata(results[i].metadata);
        items.push_back(json{
            {"rank", (int) i + 1},
            {"score", results[i].score},
            {"chunk_text", results[i].chunk_text},
            {"preview_text", sanitize_rag_preview(results[i].chunk_text)},
            {"metadata", metadata},
            {"source", format_rag_source_label(metadata)},
            {"source_info", build_source_info(metadata)},
        });
    }

    return json{
        {"query", query},
        {"retrieval_mode", params_base_.rag_hybrid_search ? "hybrid" : "dense"},
        {"count", (int) items.size()},
        {"results", std::move(items)},
    };
}

json RagServerRuntime::build_explain_payload(const std::string & query, int top_k, int timeout_ms) const {
    const auto results = search_with_metadata(query, top_k, timeout_ms);
    json evidence = json::array();

    for (size_t i = 0; i < results.size(); ++i) {
        const json metadata = parse_rag_metadata(results[i].metadata);
        evidence.push_back(json{
            {"rank", (int) i + 1},
            {"score", results[i].score},
            {"source", format_rag_source_label(metadata)},
            {"source_info", build_source_info(metadata)},
            {"preview", sanitize_rag_preview(results[i].chunk_text, 320)},
        });
    }

    return json{
        {"query", query},
        {"retrieval_mode", params_base_.rag_hybrid_search ? "hybrid" : "dense"},
        {"summary", results.empty() ? "No relevant project context was retrieved." : "Retrieved project context is ready for downstream reasoning."},
        {"evidence", std::move(evidence)},
    };
}

json RagServerRuntime::build_chat_context_payload(const std::string & query, int top_k, int timeout_ms) const {
    const auto results = search_with_metadata(query, top_k, timeout_ms);
    return json{
        {"query", query},
        {"retrieval_mode", params_base_.rag_hybrid_search ? "hybrid" : "dense"},
        {"context_block", build_rag_context_block(results)},
        {"status", build_status_payload()},
    };
}

bool RagServerRuntime::inject_chat_context(json & body, const std::string & query, int top_k, int timeout_ms) const {
    if (!enabled()) {
        return false;
    }

    const auto results = search_with_metadata(query, top_k, timeout_ms);
    const std::string context = build_rag_context_block(results);
    if (context.empty()) {
        return false;
    }

    if (!body.contains("messages") || !body["messages"].is_array()) {
        return false;
    }

    body["messages"].insert(body["messages"].begin(), json{
        {"role", "system"},
        {"content", context},
    });
    body["rag"] = true;
    return true;
}

json RagServerRuntime::build_status_payload() const {
    std::string last_error;
    std::string last_job_kind;
    bool last_reset_before_add = false;
    {
        std::lock_guard<std::mutex> lock(status_mutex_);
        last_error = last_error_;
        last_job_kind = last_job_kind_;
        last_reset_before_add = last_reset_before_add_;
    }

    int chunk_count = 0;
    if (rag_engine_) {
        chunk_count = (int) rag_engine_->get_chunk_count();
    }

    return json{
        {"enabled", enabled()},
        {"ready", ready()},
        {"status", job_active_.load() ? "indexing" : (pending_count_.load() > 0 ? "queued" : "idle")},
        {"pending", pending_count_.load()},
        {"active", job_active_.load()},
        {"jobs_completed", jobs_completed_.load()},
        {"docs_completed", docs_completed_.load()},
        {"metadata_completed", metadata_completed_.load()},
        {"chunk_count", chunk_count},
        {"last_job_kind", last_job_kind},
        {"last_reset_before_add", last_reset_before_add},
        {"last_error", last_error},
    };
}

std::string RagServerRuntime::extract_query_from_body(const json & body) {
    const std::string direct_query = body.value("query", "");
    if (!direct_query.empty()) {
        return direct_query;
    }

    if (!body.contains("messages") || !body["messages"].is_array()) {
        return "";
    }

    for (auto it = body["messages"].rbegin(); it != body["messages"].rend(); ++it) {
        if (!it->is_object()) {
            continue;
        }
        if (it->value("role", "") != "user") {
            continue;
        }
        if (!it->contains("content")) {
            continue;
        }
        const std::string text = extract_text_from_message_content((*it)["content"]);
        if (!text.empty()) {
            return text;
        }
    }

    return "";
}

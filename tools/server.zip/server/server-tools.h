#pragma once

#include "server-common.h"
#include "server-http.h"

struct server_tool {
    std::string name;
    std::string display_name;
    bool permission_write = false;

    virtual ~server_tool() = default;
    virtual json get_definition() = 0;
    virtual json invoke(json params) = 0;

    json to_json();
};

struct server_tools {
    std::vector<std::unique_ptr<server_tool>> tools;

    void setup(const std::vector<std::string> & enabled_tools, const common_params * params = nullptr);
    json invoke(const std::string & name, const json & params);
    bool is_write_tool(const std::string & name) const;

    server_http_context::handler_t handle_get;
    server_http_context::handler_t handle_post;
};
